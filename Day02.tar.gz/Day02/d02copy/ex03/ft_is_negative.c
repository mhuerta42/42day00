/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mhuerta <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/10/25 20:19:59 by mhuerta           #+#    #+#             */
/*   Updated: 2018/10/25 20:58:47 by mhuerta          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(c)
{
	write(1, &c, 1);
}

void	ft_is_negative(int n)
{
	char i;

	if (n < 0)
	{
		i = 'N';
	}
	else
	{
		i = 'P';
	}
	ft_putchar(i);
}

int		main(void)
{
	ft_is_negative(-8);
	return (0);
}
