ifconfig | grep "ether " | cut -c 8-
