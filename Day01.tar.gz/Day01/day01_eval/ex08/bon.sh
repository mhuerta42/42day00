ldapsearch sn="*bon*" | grep sn: | wc -l | rev | cut -c 1
