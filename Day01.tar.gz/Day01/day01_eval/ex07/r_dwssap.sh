cat /etc/passwd | grep -v "#" | awk "NR >= 2 && NR%2==0" | cut -f 1 -d':' | rev | sort -r
