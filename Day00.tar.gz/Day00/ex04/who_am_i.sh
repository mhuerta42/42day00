ldapwhoami | sed -n ' s/^dn://p'
